<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-10">
      <?php $__env->startComponent('include.filter-form'); ?>
            <?php echo e(route('returned')); ?>

          <?php echo $__env->renderComponent(); ?>
    </div>
  </div>
    <div class="row justify-content-center">
      <?php if(session('status')): ?>
          <div class="alert alert-success">
            <?php echo e(session('status')); ?>

          </div>
      <?php endif; ?>
        <div class="col-md-10">
          <div class="card">
            <div class="card-header">
              <div class="row text-center text-dark">
                <h3 class="mr-auto">Gražinti užsakymai</h3>
              </div>
            </div>
            <div class="card-body remove-all-padding">
              <?php if(count($param['orders']) < 1): ?>
                <h5>Grąžintų užsakymų nėra</h5>
              <?php else: ?>
                <?php $__currentLoopData = $param['orders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="row remove-side-margin">
                    <div class="col-8 fit-text-dots order-entry" onclick="window.location='<?php echo e(route('order.view', ['id' => $order->id])); ?>';">
                      <?php if($order->make != ""): ?><?php echo e($order->make); ?><?php endif; ?>
                      <?php if($order->model != ""): ?><?php echo e($order->model); ?><?php endif; ?>
                      <?php if($order->chassisNr != ""): ?><?php echo e($order->chassisNr); ?><?php endif; ?>
                      <?php if($order->year != ""): ?><?php echo e($order->year); ?><?php endif; ?>
                        <?php echo e($order->name); ?>

                    </div>
                    <div class="col-4 text-right">
                      <?php echo e($order->updated_at); ?>

                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
              <div class="col-12 text-center center-content" style="margin-top: 15px !important">
                <?php echo e($param['orders']->appends(['query' => $param['lastSearch']['query'], 'from' => $param['lastSearch']['from'], 'til' => $param['lastSearch']['til']])->links()); ?>

              </div>
            </div>
          </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manager', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>