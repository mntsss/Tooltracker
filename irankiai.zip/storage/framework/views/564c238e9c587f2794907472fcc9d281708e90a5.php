<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col-md-10">
        <div class="card bg-dark text-light">
          <div class="card-header">
            <h4>Naujos paieškos peržiūra</h4>
          </div>
          <div class="card-body">
            <h5 class="text-left"><?php echo e($param['make']); ?></h5><br />
            <h5 class="text-left"><?php echo e($param['model']); ?></h5><br />
            <h5 class="text-left"><?php echo e($param['year']); ?></h5><br />
            <h5 class="text-left"><?php echo e($param['fuel']); ?></h5><br />
            <h5 class="text-left"><?php echo e($param['vin']); ?></h5><br />
            <h5 class="text-left"><?php echo e($param['name']); ?></h5><br />
            <h5 class="text-left"><?php echo e($param['part-number']); ?></h5><br />
            <h5 class="text-left"><?php echo e($param['description']); ?></h5><br />
            <div class="col-md remove-all-margin remove-all-padding">
              <a href="<?php echo e(asset("media/uploads/".$param['image'])); ?>"><img src="<?php echo e(asset("media/uploads/".$param['image'])); ?>" alt="img" style="width: 100%; height: auto"/></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manager', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>