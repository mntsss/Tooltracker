<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card bg-dark">
                    <div class="card-header">
                        Keisti slaptažodį
                    </div>
                    <div class="card-body">
                        <form class="form-horizontal" action="<?php echo e(route("user.password.submit")); ?>" method="post">
                            <?php echo e(csrf_field()); ?>


                            <div class="form-group<?php echo e($errors->has('oldpass') ? ' has-error' : ''); ?>">
                                <label for="oldpass" class="col-md-8 control-label">Senas slaptažodis</label>

                                <div class="col-md-10">
                                    <input id="oldpass" type="password" class="form-control" name="oldpass" required autofocus>

                                    <?php if($errors->has('oldpass')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('oldpass')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <label for="password" class="col-md-8 control-label">Slaptažodis</label>

                                <div class="col-md-10">
                                    <input id="password" type="password" class="form-control" name="password" required>

                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="password-confirm" class="col-md-8 control-label">Pakartoti slaptažodį</label>

                                <div class="col-md-10">
                                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <button type="submit" class="btn btn-warning">
                                        <span class="glyphicon glyphicon-ok"></span> Keisti
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manager', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>