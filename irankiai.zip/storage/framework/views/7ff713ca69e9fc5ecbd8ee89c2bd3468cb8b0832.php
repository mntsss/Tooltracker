<div class="popup-item-box" id="<?php echo e($param['itemGroups'][$i+$j]->ItemGroupID); ?>">
    <div class="row justify-content-end remove-all-margin">
        <button type="button" class="btn btn-outline-success" style="margin: 5px 20px" onclick="$('#itemAdd').modal()"><span class="fas fa-plus"></span></button>
    </div>
</div>
