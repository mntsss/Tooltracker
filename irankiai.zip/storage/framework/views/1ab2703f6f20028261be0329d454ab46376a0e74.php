<?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value="<?php echo e($m->model); ?>">
    <?php echo e($m->model); ?>

  </option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
