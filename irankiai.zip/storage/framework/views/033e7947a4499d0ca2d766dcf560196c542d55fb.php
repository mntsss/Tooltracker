<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->

    <link rel='shortcut icon' href='<?php echo e(asset('media/favicon.ico')); ?>' type='image/x-icon' />


    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <script
  src="https://code.jquery.com/jquery-2.2.4.min.js"
  integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
  crossorigin="anonymous"></script>
  <script>
  (function($) {
    $(function() {
      var activeurl = window.location + '';
      var active = activeurl.split('?');
      $('a[href="'+active[0]+'"]').addClass('active');
    });
  })(jQuery);
  </script>
</head>
<body>
<div class="container-fluid">
    <div class="row d-flex d-flex d-lg-none d-md-none d-xl-none justify-content-end bg-dark">
          <a href="#" data-target="#sidebar" data-toggle="collapse"><i class="fas fa-bars fa-2x py-2 p-1 text-warning"></i></a>
    </div>
    <div class="row d-flex d-md-block flex-nowrap wrapper">
        <div class="col-md-3 col-lg-2 col-xl-2 float-left col-2 pl-0 pr-0 bg-dark width" id="sidebar">
            <div class="list-group border-0 card text-center text-md-left">
                <a href="#" class="list-group-item d-inline-block collapsed" data-parent="#sidebar"><i class="fas fa-home text-warning"></i> <span class="d-none d-md-inline ">Pradžia</span></a>
                <a href="<?php echo e(route('calendar')); ?>" class="list-group-item d-inline-block collapsed" data-parent="#sidebar"><i class="fa fa-calendar text-warning" aria-hidden="true"></i> <span class="d-block d-md-inline">Kalendorius</span></a>
                <a href="#menu-supply" class="list-group-item d-inline-block collapsed" data-toggle="collapse" aria-expanded="false"><i class="fas fa-cart-arrow-down text-warning"></i> <span class="d-block d-md-inline">Tiekimas</span></a>
                  <div class="collapse" id="menu-supply">
                    <a href="<?php echo e(route('active')); ?>" class="list-group-item">Aktyvūs</a>
                    <a href="<?php echo e(route('delivered')); ?>" class="list-group-item">Pristatyti</a>
                    <a href="<?php echo e(route('deleted')); ?>" class="list-group-item">Atšaukti</a>
                    <a href="<?php echo e(route('returned')); ?>" class="list-group-item">Grąžinti</a>
                  </div>
                <a href="#" class="list-group-item d-inline-block collapsed" data-parent="#sidebar"><i class="fas fa-cogs text-warning"></i> <span class="d-block d-md-inline">Darbai</span></a>
                <a href="#" class="list-group-item d-inline-block collapsed" data-parent="#sidebar"><i class="fas fa-address-book text-warning"></i> <span class="d-block d-md-inline">Klientai</span></a>
                <a href="#" class="list-group-item d-inline-block collapsed" data-parent="#sidebar"><i class="fas fa-car text-warning"></i> <span class="d-block d-md-inline">Automobiliai</span></a>
                <a href="#" class="list-group-item d-inline-block collapsed" data-parent="#sidebar"><i class="fas fa-briefcase text-warning"></i> <span class="d-block d-md-inline">Meistrai</span></a>
                <a href="#" class="list-group-item d-inline-block collapsed" data-parent="#sidebar"><i class="fas fa-history text-warning"></i> <span class="d-block d-md-inline">Istorija</span></a>
                <a href="#" class="list-group-item d-inline-block collapsed" data-parent="#sidebar"><i class="fas fa-chart-line text-warning"></i> <span class="d-block d-md-inline">Statistika</span></a>
                <a href="#menu-functions" class="list-group-item d-inline-block collapsed" data-toggle="collapse" aria-expanded="false"><i class="fa fa-star text-warning"></i> <span class="d-block d-md-inline">Funkcijos</span></a>
                  <div class="collapse" id="menu-functions">
                    <a class="list-group-item" href="<?php echo e(route('user.password')); ?>">Keisti slaptažodį</a>
                    <a class="list-group-item" href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                                     document.getElementById('logout-form').submit();">
                        Atsijungti
                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                  </div>
            </div>
        </div>
        <main class="col-md-9 col-lg-10 col-xl-10 float-left col px-5 pl-md-2 pt-2 main">
          <?php echo $__env->make('include.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</div>


    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
