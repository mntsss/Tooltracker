<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('comfirmations.order-delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('comfirmations.order-delivered', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script>
  function orderdelete(nr, name)
  {
  $('#deleteLink').attr('href', function() {
        return '/order/delete/' + nr;
    });
  $('#orderDelete .modal-body').html('<p>Atšaukti užsakymą "'+ name +'"?</p>')
    $('#orderDelete').modal();
  }
  function orderdelivered(nr, name)
  {
  $('#deliveredLink').attr('href', function() {
        return '/order/delivered/' + nr;
    });
    $('#orderDelivered .modal-body').html('<p>Ar tikrai užsakymas "'+ name +'" pristatytas?</p>')
    $('#orderDelivered').modal();
  }
  function orderreturned(nr, name)
  {
  $('#deliveredLink').attr('href', function() {
        return '/order/returned/' + nr;
    });
    $('#orderDelivered .modal-body').html('<p>Užsakymas "'+ name +'" grąžintas?</p>')
    $('#orderDelivered').modal();
  }
  function orderfound(nr, name)
  {
  $('#deliveredLink').attr('href', function() {
        return '/order/found/' + nr;
    });
    $('#orderDelivered .modal-body').html('<p>Užsakymas "'+ name +'" gautas?</p>')
    $('#orderDelivered').modal();
  }
  function orderrefresh(nr, name)
  {
  $('#deliveredLink').attr('href', function() {
        return '/order/refresh/' + nr;
    });
    $('#orderDelivered .modal-body').html('<p>Atnaujinti užsakymą "'+ name +'"?</p>')
    $('#orderDelivered').modal();
  }
  function orderreturn(nr, name)
  {
  $('#deliveredLink').attr('href', function() {
        return '/order/return/' + nr;
    });
    $('#orderDelivered .modal-body').html('<p>Gražinti užsakymą "'+ name +'"?</p>')
    $('#orderDelivered').modal();
  }
  </script>
  <div class="container">
    <div class="row">
      <div class="col-md-10 col-12">
        <div class="card bg-dark text-light">
          <div class="card-header">
            <?php if($param['order']->status == "return"): ?>
              Gražinimas:&#160;
            <?php endif; ?>
            <?php if($param['order']->make != "" && $param['order']->model != ""): ?>
              <?php echo e($param['order']->make); ?>&#160;<?php echo e($param['order']->model); ?>&#160;<?php echo e($param['order']->year); ?>

            <?php else: ?>
              <?php echo e($param['order']->make); ?>&#160;<?php echo e($param['order']->name); ?>

            <?php endif; ?>
            <?php if($param['order']->type == "search" && Auth::user()->role == "Vadybininkas"): ?>
              <form method="post" action="<?php echo e(route('search.add.another')); ?>" class="flex-row-reverse">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="make" value="<?php echo e($param['order']->make); ?>" />
                <input type="hidden" name="model" value="<?php echo e($param['order']->model); ?>" />
                <input type="hidden" name="year" value="<?php echo e($param['order']->year); ?>" />
                <input type="hidden" name="fuel" value="<?php echo e($param['order']->fuel); ?>" />
                <input type="hidden" name="vin" value="<?php echo e($param['order']->vin); ?>" />
                <input type="hidden" name="power" value="<?php echo e($param['order']->power); ?>" />
                <input type="hidden" name="cartype" value="<?php echo e($param['order']->carType); ?>" />
                <input type="hidden" name="carchassis" value="<?php echo e($param['order']->chassisNr); ?>" />
                <button type="submit" class="btn btn-outline-success" style="border-radius: 0px !important"><span class="fa fa-plus"></span>&#160;Kita detalė</button><br />
              </form>
            <?php endif; ?>
          </div>
          <div class="card-body">
            <?php if($param['order']->model != ""): ?>
              <div class="text-left">
                <?php echo e($param['order']->name); ?>

              </div>
            <?php endif; ?>
            <?php if($param['order']->timeLimit != "" && $param['order']->status != "return"): ?>
              <div class="text-left">
                <b>Pristatyti iki: <br /><u class="text-danger"><?php echo e($param['order']->timeLimit); ?></u></b>
              </div>
            <?php endif; ?>
            <?php if($param['order']->year != ""): ?>
              <div class="text-left">
                <b>Metai: </b><?php echo e($param['order']->year); ?>

              </div>
            <?php endif; ?>
            <?php if($param['order']->carType != ""): ?>
              <div class="text-left">
                <b>Kėbulo tipas: </b><?php echo e($param['order']->carType); ?>

              </div>
            <?php endif; ?>
            <?php if($param['order']->chassisNr != ""): ?>
              <div class="text-left">
                <b>Kėbulas: </b><?php echo e($param['order']->chassisNr); ?>

              </div>
            <?php endif; ?>
            <?php if($param['order']->power != ""): ?>
              <div class="text-left">
                <b>Galia: </b><?php echo e($param['order']->power); ?> kw
              </div>
            <?php endif; ?>
            <?php if($param['order']->fuel != ""): ?>
              <div class="text-left">
                <b>Kuras: </b><?php echo e($param['order']->fuel); ?>

              </div>
            <?php endif; ?>
            <?php if($param['order']->vin != ""): ?>
              <div class="text-left">
                <b>VIN: </b><?php echo e($param['order']->vin); ?>

              </div>
            <?php endif; ?>
            <?php if($param['order']->code != ""): ?>
              <div class="text-left">
                <b>Detalės kodas: </b><?php echo e($param['order']->code); ?>

              </div>
            <?php endif; ?>
            <?php if($param['order']->description != ""): ?>
              <div class="text-left">
                <b>Aprašymas: </b><?php echo e($param['order']->description); ?>

              </div>
            <?php endif; ?>
            <?php if($param['order']->image != ""): ?>
                <div class="col-md-6 remove-all-margin remove-all-padding" style="text-align:center; padding: 10px">
                  <a href="<?php echo e(asset("media/uploads/".$param['order']->image)); ?>"><img src="<?php echo e(asset("media/uploads/".$param['order']->image)); ?>" alt="img" style="width: 100%; height: auto"/></a>
                </div>

            <?php elseif(Auth::user()->role == "Vadybininkas" && $param['order']->status == "active"): ?>
                <div class="text-left">
                  <b>Įkelti nuotrauką</b>
                </div>
                <form class="form-vertical" method="post" action="<?php echo e(route('order.updatephoto.submit')); ?>" enctype="multipart/form-data" style="margin: 15px 0 !important">
                <div class="form-group row">
                  <?php echo csrf_field(); ?>
                  <div class="col-9 text-left">
                       <input type="hidden" name="id" value="<?php echo e($param['order']->id); ?>" />
                       <input name="image" type="file" id="image" class="form-control<?php echo e($errors->has('image') ? ' is-invalid' : ''); ?>" accept="image/*" placeholder="Pridėti nuotrauką" capture required>
                       <?php if($errors->has('image')): ?>
                           <span class="invalid-feedback">
                               <strong><?php echo e($errors->first('image')); ?></strong>
                           </span>
                       <?php endif; ?>
                  </div>
                  <div class="col-3">
                    <button type="submit" class="btn btn-outline-warning"><span class="fas fa-upload"></span></button>
                  </div>
                </div>
              </form>
            <?php endif; ?>
            <?php if($param['order']->address != ""): ?>
              <div class="text-left">
                <h4>Kontaktai</h4>
                <a href="geo:0,0?q=<?php echo e($param['order']->address); ?>" class="text-light"><?php echo e($param['order']->address); ?></a><br />
                <?php if($param['order']->phone != ""): ?>
                  <a href="tel:<?php echo e($param['order']->phone); ?>" class="text-light"><?php echo e($param['order']->phone); ?></a>
                <?php endif; ?>
              </div>
            <?php endif; ?>
            <div class="justify-content-center" style="padding: 10px;">
                <?php if(Auth::user()->role == "Vadybininkas"): ?>
                   <?php if($param['order']->status == "active" || $param['order']->status == "found"): ?><button type="button" class="btn btn-success btn-orders-function" onclick="orderdelivered('<?php echo e($param['order']->id); ?>', '<?php echo e(htmlspecialchars($param['order']->name, ENT_QUOTES)); ?>')"><span class="far fa-check-circle"></span>&#160;Pristatyta</button><?php endif; ?>
                   <?php if($param['order']->status == "return"): ?><button type="button" class="btn btn-success btn-orders-function" onclick="orderreturned('<?php echo e($param['order']->id); ?>', '<?php echo e(htmlspecialchars($param['order']->name, ENT_QUOTES)); ?>')"><span class="far fa-check-circle"></span>&#160;Grąžinta</button><?php endif; ?>
                   <?php if($param['order']->status == "active" || $param['order']->status == "return"): ?><button type="button" class="btn btn-danger btn-orders-function" onclick="orderdelete('<?php echo e($param['order']->id); ?>', '<?php echo e(htmlspecialchars($param['order']->name, ENT_QUOTES)); ?>')"><span class="far fa-times-circle"></span>&#160;Atšaukti</button><?php endif; ?>
                   <?php if($param['order']->status == "deleted"): ?><button type="button" class="btn btn-success btn-orders-function" onclick="orderrefresh('<?php echo e($param['order']->id); ?>','<?php echo e(htmlspecialchars($param['order']->name, ENT_QUOTES)); ?>')"><span class="fas fa-redo"></span>&#160;Atnaujinti</button><?php endif; ?>
                   <?php if($param['order']->status == "delivered"): ?><button type="button" class="btn btn-warning btn-orders-function" onclick="orderreturn('<?php echo e($param['order']->id); ?>','<?php echo e(htmlspecialchars($param['order']->name, ENT_QUOTES)); ?>')"><span class="fas fa-reply"></span>&#160;Grąžinti</button><?php endif; ?>
                <?php elseif(Auth::user()->role == "Tiekėjas"): ?>
                  <?php if($param['order']->status == "active"): ?><button type="button" class="btn btn-success btn-orders-function" onclick="orderfound('<?php echo e($param['order']->id); ?>', '<?php echo e(htmlspecialchars($param['order']->name, ENT_QUOTES)); ?>')"><span class="far fa-check-circle"></span>&#160;Gavau</button><?php endif; ?>
                  <?php if($param['order']->status == "return"): ?><button type="button" class="btn btn-success btn-orders-function" onclick="orderreturned('<?php echo e($param['order']->id); ?>', '<?php echo e(htmlspecialchars($param['order']->name, ENT_QUOTES)); ?>')"><span class="far fa-check-circle"></span>&#160;Grąžinau</button><?php endif; ?>
                <?php endif; ?>
            </div>
          </div>
        </div>
        <div class="card bg-dark" style="margin-top:20px !important">
          <div class="card-header">
            Užsakymo istorija
          </div>
            <div class="card-body text-light remove-all-padding">
              <?php $__currentLoopData = $param['actions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row history-row remove-all-margin" style=":hover{cursor: default !important;}">
                  <div class="col-sm-9">
                    <?php echo $a->stringOutput(); ?>

                  </div>
                  <div class="col-sm-3 text-right">
                    <?php echo e($a->created_at); ?>

                  </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manager', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>