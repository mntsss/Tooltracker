  <div class="container">
    <div class="row">
      <div class="col-md-offset-4 col-md-4" style= "text-align: center; padding-top:50px">
        <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset("media/logo.png")); ?>" alt="logo" style="width: 450px"/></a>
      </div>
    </div>
    <div class="row" style= "text-align: center; padding-top:80px">
      <h2 align="center">Įvyko klaida. Bandykite grįžti, perkrauti puslapį ir kartoti veiksmą. Jeigu klaida kartojasi, susisiekite su administracija.</h2>
    </div>
  </div>
