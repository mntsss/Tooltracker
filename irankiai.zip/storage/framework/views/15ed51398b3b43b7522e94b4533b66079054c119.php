<div id="orderDelivered" class="modal fade" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" tabindex="-1">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Patvirtinimas</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      </div>
      <div class="modal-footer">
        <a href="order/delivered/" id="deliveredLink"><button type="button" class="btn btn-success">Taip</button></a>
        <button type="button" class="btn btn-danger" data-dismiss="modal">Ne</button>
      </div>
    </div>

  </div>
</div>
