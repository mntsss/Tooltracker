<?php $__env->startSection('content'); ?>
  <script>
  function loadModels(){
    make = $('#vehicleMake').val();
    $.ajax({
      url: 'vehicles/models',
      type: 'POST',
      dataType: 'html',
      data: {_token: "<?php echo e(csrf_token()); ?>", make: make},
      success: function(data){
          $('#vehicleModel').empty().append(data);
        }
      });
    }
  </script>
  <form action="" method="post">
  <div class="row justify-content-center">
    <div class="col-md-6 flex-column align-self-stretch">
      <div class="card">
        <div class="card-header bg-dark">
          <span class="fas fa-user"></span> Klientas
        </div>
        <div class="card-body">
          <div class="form-group">
            <label for="clientName">Vardas, pavardė</label>
            <div class="input-group">
              <span class="input-group-text"><i class="fas fa-user"></i></span>
              <input type="text" class="form-control" name="clientName" required />
            </div>
          </div>
          <div class="form-group">
            <label for="clientPhone">Telefonas</label>
            <div class="input-group">
              <span class="input-group-text"><i class="fas fa-phone"></i></span>
              <input type="text" class="form-control" name="clientPhone" required />
            </div>
          </div>
          <div class="form-group">
            <label for="clientCompany">Įmonė</label>
            <div class="input-group">
              <span class="input-group-text"><i class="far fa-building"></i></span>
              <input type="text" class="form-control" name="clientCompany" />
            </div>
          </div>
          <div class="form-group">
            <label for="clientCompanyCode">Įmonės kodas</label>
            <div class="input-group">
              <span class="input-group-text"><i class="far fa-address-card"></i></span>
              <input type="text" class="form-control" name="clientCompanyCode" />
            </div>
          </div>
          <div class="form-group">
            <label for="clientEmail">El. paštas</label>
            <div class="input-group">
              <span class="input-group-text"><i class="far fa-envelope"></i></span>
              <input type="email" class="form-control" name="clientEmail" />
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-md-6 flex-column disableddiv">
      <div class="card">
        <div class="card-header bg-dark">
          <span class="fas fa-car"></span>&#160;Automobilis
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-md">
              <div class="form-group">
                <label for="vehicleMake" class="col-form-label text-md-right">Gamintojas</label>
                <?php if(isset($param['previous']['vehicleMake'])): ?>
                  <input type="text" name="vehicleMake" value="<?php echo e($param['previous']['vehicleMake']); ?>" class="form-control" readonly />
                <?php else: ?>
                <select name="vehicleMake" id="vehicleMake" class="form-control" onchange="loadModels()" value="<?php echo e(old('vehicleMake')); ?>">
                  <option value="">
                    -Pasirinkite-
                  </option>
                  <?php $__currentLoopData = $param['makes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($m->make); ?>">
                      <?php echo e($m->make); ?>

                    </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              <?php endif; ?>
              </div>
            </div>
            <div class="col-md">
              <div class="form-group">
                <label for="vehicleModel" class="col-form-label text-md-right">Modelis</label>
                <?php if(isset($param['previous']['vehicleModel'])): ?>
                  <input type="text" name="vehicleModel" value="<?php echo e($param['previous']['vehicleModel']); ?>" class="form-control" readonly />
                <?php else: ?>
                <select name="vehicleModel" id="vehicleModel" class="form-control" value="<?php echo e(old('vehicleModel')); ?>">
                  <option>
                    --
                  </option>
                </select>
              <?php endif; ?>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md">
              <div class="form-group">
                <label for="vehicleYear" class="col-form-label text-md-right">Metai</label>
                <?php if(isset($param['previous']['vehicleYear'])): ?>
                  <input type="text" name="vehicleYear" value="<?php echo e($param['previous']['vehicleYear']); ?>" class="form-control" readonly />
                <?php else: ?>
                <select name="vehicleYear" id="vehicleYear" class="form-control" value="<?php echo e(old('vehicleYear')); ?>">
                  <option value="">
                    -Pasirinkite-
                  </option>
                  <?php for($y =  $param['years']; $y >= 1975; $y--): ?>
                    <option value="<?php echo e($y); ?>">
                      <?php echo e($y); ?>

                    </option>
                  <?php endfor; ?>
                </select>
              <?php endif; ?>
              </div>
            </div>
            <div class="col-md">
              <div class="form-group">
                <label for="vehicleFuel" class="col-form-label text-md-right">Kuro tipas</label>
                <?php if(isset($param['previous']['vehicleFuel'])): ?>
                  <input type="text" name="vehicleFuel" value="<?php echo e($param['previous']['vehicleFuel']); ?>" class="form-control" readonly />
                <?php else: ?>
                <select name="vehicleFuel" id="vehicleFuel" class="form-control" value="<?php echo e(old('vehicleFuel')); ?>">
                  <option value="">--</option>
                  <option value="Dyzelinas">Dyzelinas</option>
                  <option value="Benzinas">Benzinas</option>
                  <option value="Benzinas / dujos">Benzinas / dujos</option>
                  <option value="Benzinas / elektra">Benzinas / elektra</option>
                  <option value="Elektra">Elektra</option>
                  <option value="Dyzelinas / elektra">Dyzelinas / elektra</option>
                  <option value="Dyzelinas / dujos">Dyzelinas / dujos</option>
                  <option value="Bioetanolis (E85)">Bioetanolis (E85)</option>
                  <option value="Kita">Kita</option>
                </select>
              <?php endif; ?>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md">
              <div class="form-group">
                <label for="vehicleType" class="col-form-label text-md-right">Kėbulo tipas</label>
                <?php if(isset($param['previous']['vehicleType'])): ?>
                  <input type="text" name="vehicleType" value="<?php echo e($param['previous']['vehicleType']); ?>" class="form-control" readonly />
                <?php else: ?>
                <select name="vehicleType" class="form-control" value="<?php echo e(old('vehicleType')); ?>">
                  <option value="">--</option>
                  <option value="Sedanas">Sedanas</option>
                  <option value="Hečbekas">Hečbekas</option>
                  <option value="Universalas">Universalas</option>
                  <option value="Vienatūris">Vienatūris</option>
                  <option value="Visureigis">Visureigis</option>
                  <option value="Kupė">Kupė</option>
                  <option value="Komercinis">Komercinis</option>
                  <option value="Kabrioletas">Kabrioletas</option>
                  <option value="Limuzinas">Limuzinas</option>
                  <option value="Pikapas">Pikapas</option>
                  <option value="Kita">Kita</option></select>
                </select>
              <?php endif; ?>
              </div>
            </div>
          <div class="col-md">
            <div class="form-group">
              <label for="vehicleChassis" class="col-form-label text-md-right">Kėbulas</label>
              <?php if(isset($param['previous']['vehicleChassis'])): ?>
                <input type="text" name="vehicleChassis" value="<?php echo e($param['previous']['vehicleChassis']); ?>" class="form-control" readonly />
              <?php else: ?>
              <input type="text" name="vehicleChassis" class="form-control" value="<?php echo e(old('vehicleChassis')); ?>" placeholder="Pvz.: E46, W212, B5..." maxlength="15"/>
            <?php endif; ?>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md">
            <div class="form-group">
              <label for="vehiclePower" class="col-form-label text-md-right">Galingumas (kw)</label>
              <?php if(isset($param['previous']['vehiclePower'])): ?>
                <input type="number" name="vehiclePower" value="<?php echo e($param['previous']['vehiclePower']); ?>" class="form-control" readonly />
              <?php else: ?>
                <input id="vehiclePower" type="number" class="form-control<?php echo e($errors->has('vehiclePower') ? ' is-invalid' : ''); ?>" name="power" value="0">
              <?php endif; ?>
                <?php if($errors->has('vehiclePower')): ?>
                    <span class="invalid-feedback">
                        <strong><?php echo e($errors->first('vehiclePower')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
          </div>
          <div class="col-md">
              <div class="form-group">
                <label for="vehicleVin" class="col-form-label text-md-right">VIN kodas</label>
                <input id="vehicleVin" type="text" class="form-control<?php echo e($errors->has('vehicleVin') ? ' is-invalid' : ''); ?>" name="vehicleVin" value="<?php echo e(old('vehicleVin')); ?>" maxlength="25" style="text-transform:uppercase" required>

                <?php if($errors->has('vehicleVin')): ?>
                    <span class="invalid-feedback">
                        <strong><?php echo e($errors->first('vehicleVin')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
          </div>
        </div>

        <div class="row">
          <div class="col-md">
              <div class="form-group">
                <label for="vehiclePlates" class="col-form-label text-md-right">Valstybinis numeris</label>
                <input id="vehiclePlates" type="text" class="form-control<?php echo e($errors->has('vehiclePlates') ? ' is-invalid' : ''); ?>" name="vehiclePlates" value="<?php echo e(old('vehiclePlates')); ?>" maxlength="6" style="text-transform:uppercase">

                <?php if($errors->has('vehiclePlates')): ?>
                    <span class="invalid-feedback">
                        <strong><?php echo e($errors->first('vehiclePlates')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
          </div>
          <div class="col-md">
              <div class="form-group">
                <label for="vehicleCapacity" class="col-form-label text-md-right">Kubatūra</label>
                <input id="vehicleCapacity" type="number" class="form-control<?php echo e($errors->has('vehicleCapacity') ? ' is-invalid' : ''); ?>" name="vehicleCapacity" value="0">

                <?php if($errors->has('vehicleCapacity')): ?>
                    <span class="invalid-feedback">
                        <strong><?php echo e($errors->first('vehicleCapacity')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
          </div>
        </div>

        </div>
      </div>
    </div>
  </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>