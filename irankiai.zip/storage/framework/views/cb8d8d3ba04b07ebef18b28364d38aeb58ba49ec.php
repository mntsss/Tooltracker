<?php $__env->startSection('content'); ?>
<?php echo $__env->make('comfirmations.order-delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('comfirmations.order-delivered', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>
setTimeout(function(){
    location = ''
  },180000);
function orderdelete(nr, name)
{
$('#deleteLink').attr('href', function() {
      return '/order/delete/' + nr;
  });
$('#orderDelete .modal-body').html('<p>Atšaukti užsakymą "'+ name +'"?</p>')
  $('#orderDelete').modal();
}
function orderdelivered(nr, name)
{
$('#deliveredLink').attr('href', function() {
      return '/order/delivered/' + nr;
  });
  $('#orderDelivered .modal-body').html('<p>Ar tikrai užsakymas "'+ name +'" pristatytas?</p>')
  $('#orderDelivered').modal();
}
function orderreturned(nr, name)
{
$('#deliveredLink').attr('href', function() {
      return '/order/returned/' + nr;
  });
  $('#orderDelivered .modal-body').html('<p>Užsakymas "'+ name +'" grąžintas?</p>')
  $('#orderDelivered').modal();
}
</script>
<div class="container">
    <div class="row justify-content-center">
      <?php if(session('status')): ?>
          <div class="alert alert-success">
            <?php echo e(session('status')); ?>

          </div>
      <?php endif; ?>
        <div class="col-md-10">
          <div class="card">
            <div class="card-header">
              <div class="row text-center text-dark">
                <h3 class="mr-auto">Aktyvūs užsakymai</h3>
                <?php if(Auth::user()->role == "Vadybininkas"): ?>
                <a href="<?php echo e(route('order.add')); ?>" class="btn btn-dark"><span class="fas fa-car text-white">Atvežti</span></a>&#160;
                <a href="<?php echo e(route('search.add')); ?>" class="btn btn-dark"><span class="fas fa-search text-white">Surasti</span></a>
              <?php endif; ?>
              </div>
            </div>
            <div class="card-body remove-all-padding">
              <?php if(count($param['orders']) < 1): ?>
                <h6>Aktyvių užsakymų nėra</h6>
              <?php else: ?>
                <?php $__currentLoopData = $param['orders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="row remove-side-margin">
                    <div class="col-sm-11 col-10 fit-text-dots order-entry" onclick="window.location='<?php echo e(route('order.view', ['id' => $order->id])); ?>';">
                      <?php if($order->important && $order->status == "active"): ?><span class="fas fa-exclamation text-danger"></span>&#160;<?php endif; ?>
                      <?php if($order->timeLimit != "" && $order->status == "active"): ?><span class="far fa-clock"></span>
                      <?php elseif($order->status == "return"): ?><span class="fas fa-reply"></span>
                      <?php elseif($order->status == "found"): ?><span class="fas fa-car"></span><?php endif; ?>
                      <?php if($order->make != ""): ?><?php echo e($order->make); ?><?php endif; ?>
                      <?php if($order->model != ""): ?><?php echo e($order->model); ?><?php endif; ?>
                      <?php if($order->chassisNr != ""): ?><?php echo e($order->chassisNr); ?><?php endif; ?>
                      <?php if($order->year != ""): ?><?php echo e($order->year); ?><?php endif; ?>
                        <?php echo e($order->name); ?>

                    </div>
                    <div class="col-sm-1 col-2 text-center btn-functions">
                       <span class="fas fa-angle-double-down text-dark"></span>
                       <div class="functions-box">
                         <div class="btn-group-vertical">
                           <?php if(Auth::user()->role == "Vadybininkas"): ?>
                              <?php if($order->status == "active" || $order->status == "found"): ?><button type="button" class="btn btn-success btn-orders-function" onclick="orderdelivered('<?php echo e($order->id); ?>', '<?php echo e(htmlspecialchars($order->name, ENT_QUOTES)); ?>')"><span class="far fa-check-circle"></span>&#160;Pristatyta</button><?php endif; ?>
                              <?php if($order->status == "return"): ?><button type="button" class="btn btn-success btn-orders-function" onclick="orderreturned('<?php echo e($order->id); ?>', '<?php echo e(htmlspecialchars($order->name, ENT_QUOTES)); ?>')"><span class="far fa-check-circle"></span>&#160;Grąžinta</button><?php endif; ?>
                              <?php if($order->status != "found"): ?><button type="button" class="btn btn-danger btn-orders-function" onclick="orderdelete('<?php echo e($order->id); ?>', '<?php echo e(htmlspecialchars($order->name, ENT_QUOTES)); ?>')"><span class="far fa-times-circle"></span>&#160;Atšaukti</button><?php endif; ?>
                           <?php elseif(Auth::user()->role == "Tiekėjas"): ?>
                             <?php if($order->status == "active"): ?><a href="<?php echo e(route('order.found', ['id' => $order->id])); ?>" class="btn btn-success btn-orders-function"><span class="far fa-check-circle"></span>&#160;Gavau</a><?php endif; ?>
                             <?php if($order->status == "return"): ?><button type="button" class="btn btn-success btn-orders-function" onclick="orderreturned('<?php echo e($order->id); ?>', '<?php echo e(htmlspecialchars($order->name, ENT_QUOTES)); ?>')"><span class="far fa-check-circle"></span>&#160;Grąžinau</button><?php endif; ?>
                           <?php endif; ?>
                         </div>
                       </div>
                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
              <div class="col-12 text-center center-content" style="margin-top: 15px !important">
                <?php echo e($param['orders']->links()); ?>

              </div>

            </div>
          </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manager', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>