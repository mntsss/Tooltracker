<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row justify-content-center">
    <?php echo $__env->make("include.filter-history", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="card bg-dark" style="margin-top:20px !important">
        <div class="card-body text-light remove-all-padding">
          <?php $__currentLoopData = $param['actions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row history-row remove-all-margin" onclick="window.location='<?php echo e(route('order.view', ['id' => $a->orderId])); ?>';">
              <div class="col-sm-9">
                <?php echo $a->stringOutput(); ?>

              </div>
              <div class="col-sm-3 text-right">
                <?php echo e($a->created_at); ?>

              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <div class="col-12 text-center center-content border border-dark" style="margin-top: 15px !important">
            <?php echo e($param['actions']->appends(['query' => $param['lastSearch']['query'], 'user' => $param['lastSearch']['user'], 'from' => $param['lastSearch']['from'], 'til' => $param['lastSearch']['til']])->links()); ?>

          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manager', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>