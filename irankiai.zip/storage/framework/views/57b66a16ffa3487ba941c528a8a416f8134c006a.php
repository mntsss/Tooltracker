<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col-md-10 col-12">
        <div class="card bg-dark text-light">
          <div class="card-header">
            <?php if($order->make != "" && $order->model != ""): ?>
              <?php echo e($order->make); ?>&#160;<?php echo e($order->model); ?>&#160;<?php echo e($order->year); ?>

            <?php else: ?>
              <?php echo e($order->make); ?>&#160;<?php echo e($order->name); ?>

            <?php endif; ?>
          </div>
          <div class="card-body">
            <?php if($order->model != ""): ?>
              <div class="text-left">
                <?php echo e($order->name); ?>

              </div>
            <?php endif; ?>
            <?php if($order->year != ""): ?>
              <div class="text-left">
                <b>Metai: </b><?php echo e($order->year); ?>

              </div>
            <?php endif; ?>
            <?php if($order->fuel != ""): ?>
              <div class="text-left">
                <b>Kuras: </b><?php echo e($order->fuel); ?>

              </div>
            <?php endif; ?>
            <?php if($order->chassisNr != ""): ?>
              <div class="text-left">
                <b>Kėbulas: </b><?php echo e($order->chassisNr); ?>

              </div>
            <?php endif; ?>
            <?php if($order->carType != ""): ?>
              <div class="text-left">
                <b>Kėbulo tipas: </b><?php echo e($order->carType); ?>

              </div>
            <?php endif; ?>
            <?php if($order->vin != ""): ?>
              <div class="text-left">
                <b>VIN: </b><?php echo e($order->vin); ?>

              </div>
            <?php endif; ?>
            <form method="post" action="<?php echo e(route('search.add.another')); ?>">
              <?php echo e(csrf_field()); ?>

              <input type="hidden" name="make" value="<?php echo e($order->make); ?>" />
              <input type="hidden" name="model" value="<?php echo e($order->model); ?>" />
              <input type="hidden" name="year" value="<?php echo e($order->year); ?>" />
              <input type="hidden" name="fuel" value="<?php echo e($order->fuel); ?>" />
              <input type="hidden" name="vin" value="<?php echo e($order->vin); ?>" />
              <input type="hidden" name="power" value="<?php echo e($order->power); ?>" />
              <input type="hidden" name="cartype" value="<?php echo e($order->carType); ?>" />
              <input type="hidden" name="carchassis" value="<?php echo e($order->chassisNr); ?>" />
              <button type="submit" class="btn btn-outline-success" style="border-radius: 0px !important"><span class="fa fa-plus"></span>&#160;Pridėti kitą detalę paieškai</button><br />
            </form>

            <?php if($order->code != ""): ?>
              <div class="text-left">
                <b>Detalės kodas: </b><?php echo e($order->code); ?>

              </div>
            <?php endif; ?>
            <?php if($order->description != ""): ?>
              <div class="text-left">
                <b>Aprašymas: </b><?php echo e($order->description); ?>

              </div>
            <?php endif; ?>
            <?php if($order->image != ""): ?>
                <div class="col-md remove-all-margin" style="max-width: 350px; max-height: 350px; text-align:center; padding: 10px !important">
                  <a href="<?php echo e(asset("media/uploads/".$order->image)); ?>"><img src="<?php echo e(asset("media/uploads/".$order->image)); ?>" alt="img" style="max-width: 340px; height: auto"/></a>
                </div>
            <?php endif; ?>
            <?php if($order->timeLimit != ""): ?>
              <div class="text-left">
                <b>Pristatyti iki: <br /><u><?php echo e($order->timeLimit); ?></u></b>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manager', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>