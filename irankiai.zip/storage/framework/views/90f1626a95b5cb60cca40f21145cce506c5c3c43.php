<div class="card">
  <div class="card-header">
    <div class="row text-center text-dark">
      <h3 class="mr-auto">Aktyvūs užsakymai</h3>
      <a href="<?php echo e(route('order.add')); ?>" class="btn btn-success"><span class="fas fa-car text-white">Atvežti</span></a>&#160;
      <a href="<?php echo e(route('search.add')); ?>" class="btn btn-success"><span class="fas fa-search text-white">Surasti</span></a>
    </div>
  </div>
  <div class="card-body remove-all-padding">
    <?php if(count($param['standingOrders']) < 1): ?>
      <h4>Aktyvių užsakymų nėra</h4>
    <?php else: ?>
      <?php $__currentLoopData = $param['standingOrders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row remove-side-margin <?php if($order->important): ?>bg-danger <?php endif; ?>">
          <div class="col-sm-11 col-10 fit-text-dots order-entry" onclick="window.location='<?php echo e(route('order.view', ['id' => $order->id])); ?>';">
            <?php if($order->timeLimit != ""): ?><span class="far fa-clock"></span>
            <?php elseif($order->status == "return"): ?><span class="fas fa-reply"></span><?php endif; ?>
            <?php if($order->make != ""): ?><?php echo e($order->make); ?><?php endif; ?>
            <?php if($order->model != ""): ?><?php echo e($order->model); ?><?php endif; ?>
              <?php echo e($order->name); ?>

          </div>
          <div class="col-sm-1 col-2 text-center btn-functions">
             <span class="fas fa-angle-double-down text-dark "></span>
             <div class="functions-box">
               <div class="btn-group-vertical">
                 <button type="button" class="btn btn-success btn-orders-function" onclick="orderdelivered('<?php echo e($order->id); ?>', '<?php echo e($order->name); ?>')"><span class="far fa-check-circle"></span>&#160;Pristatyta</button>
                 <button type="button" class="btn btn-danger btn-orders-function" onclick="orderdelete('<?php echo e($order->id); ?>', '<?php echo e($order->name); ?>')"><span class="far fa-times-circle"></span>&#160;Atšaukti</button>
               </div>
             </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php echo e($param['standingOrders']->links()); ?>

  </div>
</div>
