<?php $__env->startSection('content'); ?>
        <nav class="navbar navbar-dark bg-dark remove-all-margin remove-all-padding">
            <div class="container">
                  <div class="navbar" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <?php if(Auth::user()->role == "Vadybininkas"): ?>
                      <ul class="nav nav-tabs nav-stacked mr-auto">
                        <li class="nav-item">
                          <a href="<?php echo e(route('active')); ?>" class="nav-link">Aktyvūs</a>
                        </li>
                        <li class="nav-item">
                          <a href="<?php echo e(route('delivered')); ?>" class="nav-link">Pristatyti</a>
                        </li>
                        <li class="nav-item">
                          <a href="<?php echo e(route('deleted')); ?>" class="nav-link">Atšaukti</a>
                        </li>
                        <li class="nav-item">
                          <a href="<?php echo e(route('returned')); ?>" class="nav-link">Grąžinti</a>
                        </li>
                      </ul>
                    <?php endif; ?>
                </div>
            </div>
        </nav>

        <main class="py-4">
          <?php echo $__env->make('include.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->yieldContent('orders'); ?>
        </main>

    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>