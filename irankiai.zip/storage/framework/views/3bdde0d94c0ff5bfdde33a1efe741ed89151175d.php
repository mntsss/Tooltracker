<?php $__env->startSection('content'); ?>
<?php echo $__env->make('comfirmations.order-delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('comfirmations.order-delivered', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
    <div class="row justify-content-center">
      <?php if(session('status')): ?>
          <div class="alert alert-success">
            <?php echo e(session('status')); ?>

          </div>
      <?php endif; ?>
        <div class="col-md-10">
            <?php echo $__env->make('include.standing-orders', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manager', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>