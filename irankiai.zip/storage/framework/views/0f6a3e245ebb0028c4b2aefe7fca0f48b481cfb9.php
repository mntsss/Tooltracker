<div id="categoryAdd" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title danger">Pridėti įrankių grupę</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form class="form-horizontal" method="POST" action="<?php echo e(route('itemgroup.create')); ?>" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                <label for="name" class="col-md-4 control-label">Pavadinimas</label>

                <div class="col-md-6">
                    <input id="name" type="name" class="form-control" name="name" value="<?php echo e(old('name')); ?>" maxlength="25" required autofocus>

                    <?php if($errors->has('name')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
                    <label for="image" class="col-md-4 control-label">Atvaizdas</label>

                    <div class="col-md-6 text-right">
                         <input name="image" type="file" id="image" class="form-control" accept="image/*" capture>
                         <?php if($errors->has('image')): ?>
                             <span class="invalid-feedback">
                                 <strong><?php echo e($errors->first('image')); ?></strong>
                             </span>
                         <?php endif; ?>
                    </div>
                </div>

            <div class="form-group">
                <div class="col-md-6 col-md-offset-4">
                    <button type="submit" class="btn btn-primary">
                        Pridėti
                    </button>
                </div>
            </div>
        </form>
      </div>
    </div>

  </div>
</div>
