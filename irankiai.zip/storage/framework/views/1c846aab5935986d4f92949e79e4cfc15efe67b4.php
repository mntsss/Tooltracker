<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('include.category-add-modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('include.item-add-modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script>
  var items = <?php echo $param['items']; ?>;
  jQuery.fn.center = function () {
    if ($(window).width() <= 768) {
        this.css("position","absolute");
    }
    else {
        this.css("position","fixed");
    }
    this.css("left", Math.max(0, (($(window).width() - $(this).outerWidth()) / 2) + $(window).scrollLeft()) + "px");
    return this;
}

  function toggleGroupDesc(box, id){

     $('.popup-item-box').css('width', $('.container').width());
     $('#'+id).css('height', Object.keys(items[id]).length*55+55);
     console.log(items[id]);
     $('#'+id).center();
    if ($('#'+id).css('display') === 'none')
    {
        $('.item-box-panel').css('box-shadow', '0px 0px 0px 5px #0F3F75');
        box.css('box-shadow', '0px 0px 0px 10px #C02222');
        $('.popup-item-box').hide('400');
        $('#'+id).show('400');
    }
    else{
        box.css('box-shadow', '0px 0px 0px 5px #0F3F75');
        $('.popup-item-box').hide('400');
    }
    };

  </script>

  <div class="container">
    <div class="row row-title navbar-keytracker">
      Įrankių kategorijos
    </div>
    <?php if(count($param['itemGroups']) == 0): ?>
      <div class="row">
        <div class="col-md-2" style="padding: 10px">
          <div class="item-box-panel" onclick="$('#categoryAdd').modal()">
              <div class="item-add-box" style="height: 100% !important">
                  <span class="fas fa-plus text-success"></span>
              </div>
            </div>
          </div>
        </div>
    <?php endif; ?>
        <?php for($i = 0; $i <= count($param['itemGroups'])-1; $i +=6): ?>

              <?php if($i == 0): ?>
                <div class="row">
                  <div class="col-md-2" style="padding: 10px">
                    <div class="item-box-panel" onclick="$('#categoryAdd').modal()">
                        <div class="item-add-box" style="height: 100% !important">
                            <span class="fas fa-plus text-success"></span>
                        </div>
                      </div>
                    </div>
                <?php for($j=0; $j < 5; $j++): ?>
                    <?php if(isset($param['itemGroups'][$i+$j])): ?>
                    <div class="col-md-2" style="padding: 10px" >
                      <?php $__env->startComponent('components.group-box'); ?>
                        <?php $__env->slot('itemGroupId'); ?>
                          <?php echo e($param['itemGroups'][$i+$j]->ItemGroupID); ?>

                        <?php $__env->endSlot(); ?>
                          <?php $__env->slot('image'); ?>
                              <?php if($param['itemGroups'][$i+$j]['ItemGroupImage'] != null): ?>
                                  <img src="<?php echo e(asset('media/uploads/'.urlencode(Auth::user()->ClientID)."/".$param['itemGroups'][$i+$j]['ItemGroupImage'])); ?>" alt="item-img" class="item-img"/>
                              <?php else: ?>
                                  <div class="item-noimg">
                                      <span class="far fa-folder-open text-warning"></span>
                                  </div>
                              <?php endif; ?>
                          <?php $__env->endSlot(); ?>
                          <?php $__env->slot('groupName'); ?>
                              <?php echo e($param['itemGroups'][$i+$j]['ItemGroupName']); ?>

                          <?php $__env->endSlot(); ?>
                      <?php echo $__env->renderComponent(); ?>
                        <?php echo $__env->make('include.item-list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                    <?php endif; ?>
                <?php endfor; ?>
                </div>
                <?php
                    $i -= 1;
                ?>
              <?php else: ?>
                <div class="row">
                <?php for($j=0; $j < 6; $j++): ?>
                    <?php if(isset($param['itemGroups'][$i+$j])): ?>
                    <div class="col-md-2" style="padding: 10px">
                        <?php $__env->startComponent('components.group-box'); ?>
                          <?php $__env->slot('itemGroupId'); ?>
                            <?php echo e($param['itemGroups'][$i+$j]->ItemGroupID); ?>

                          <?php $__env->endSlot(); ?>
                            <?php $__env->slot('image'); ?>
                                <?php if($param['itemGroups'][$i+$j]['ItemGroupImage'] != null): ?>
                                    <img src="<?php echo e(asset('media/uploads/'.urlencode(Auth::user()->ClientID)."/".$param['itemGroups'][$i+$j]['ItemGroupImage'])); ?>" alt="item-img" class="item-img"/>
                                <?php else: ?>
                                    <div class="item-noimg">
                                        <span class="far fa-folder-open text-warning"></span>
                                    </div>
                                <?php endif; ?>
                            <?php $__env->endSlot(); ?>
                            <?php $__env->slot('groupName'); ?>
                                <?php echo e($param['itemGroups'][$i+$j]['ItemGroupName']); ?>

                            <?php $__env->endSlot(); ?>
                        <?php echo $__env->renderComponent(); ?>
                        <?php echo $__env->make('include.item-list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                    <?php endif; ?>
                <?php endfor; ?>
            </div>
          <?php endif; ?>
        <?php endfor; ?>

    </div>
<script>
  $(document).ready(function(){
    $('a[data-toggle="tooltip"]').tooltip({
      container: 'body'
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>