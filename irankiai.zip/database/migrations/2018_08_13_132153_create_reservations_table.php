<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateReservationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('reservations', function (Blueprint $table) {
            $table->increments('ReservationID');
            $table->boolean('ReservationDelivered')->default(0);
            $table->integer('ReservationRecipientUserID')->nullable();
            $table->text('ReservationConfirmSignature')->nullable();
            $table->string('ReservationConfirmCardNr')->nullable();
            $table->integer('UserID');
            $table->integer('ObjectID')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('reservations');
    }
}
